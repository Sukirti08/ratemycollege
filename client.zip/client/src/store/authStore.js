import { create } from 'zustand';
import axiosInstance from '../api/axiosInstance.js';

const useAuthStore = create((set) => ({
  user: null,
  isLoading: false,
  isAuthenticated: false,

  checkAuth: async () => {
    set({ isLoading: true });
    try {
      const response = await axiosInstance.get('/auth/me');
      set({ user: response.data, isAuthenticated: true, isLoading: false });
    } catch (error) {
      set({ user: null, isAuthenticated: false, isLoading: false });
    }
  },

  logout: async () => {
    try {
      await axiosInstance.post('/auth/logout');
    } catch (_) {
      // best-effort
    } finally {
      set({ user: null, isAuthenticated: false });
    }
  },

  setUser: (user) => set({ user, isAuthenticated: true }),
}));

export default useAuthStore;
