import { create } from 'zustand';

const useToastStore = create((set, get) => ({
  toasts: [],

  addToast: ({ message, type = 'info', duration = 3000 }) => {
    const id = Date.now();
    set((state) => ({ toasts: [...state.toasts, { id, message, type }] }));
    setTimeout(() => get().removeToast(id), duration);
  },

  removeToast: (id) => {
    set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) }));
  },

  success: (message) => get().addToast({ message, type: 'success' }),
  error: (message) => get().addToast({ message, type: 'error' }),
  info: (message) => get().addToast({ message, type: 'info' }),
  warning: (message) => get().addToast({ message, type: 'warning' }),
}));

export default useToastStore;
