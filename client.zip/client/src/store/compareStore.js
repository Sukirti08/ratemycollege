import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const useCompareStore = create(
  persist(
    (set, get) => ({
      colleges: [],

      addCollege: (college) => {
        const { colleges } = get();
        if (colleges.length >= 3) return false;
        if (colleges.some((c) => c._id === college._id)) return false;
        set({ colleges: [...colleges, college] });
        return true;
      },

      removeCollege: (collegeId) => {
        set((state) => ({
          colleges: state.colleges.filter((c) => c._id !== collegeId),
        }));
      },

      clearAll: () => set({ colleges: [] }),

      isInCompare: (collegeId) => {
        return get().colleges.some((c) => c._id === collegeId);
      },
    }),
    {
      name: 'compare-colleges',
    }
  )
);

export default useCompareStore;
