import { useRef, useState, useEffect, useCallback } from "react";

export default function useInfiniteScroll({ onLoadMore, hasMore, threshold = 0.1 }) {
  const sentinelRef = useRef(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleIntersect = useCallback(
    async (entries) => {
      const [entry] = entries;
      if (entry.isIntersecting && hasMore && !isLoading) {
        setIsLoading(true);
        try {
          await onLoadMore();
        } finally {
          setIsLoading(false);
        }
      }
    },
    [hasMore, isLoading, onLoadMore]
  );

  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel) return;

    const observer = new IntersectionObserver(handleIntersect, { threshold });
    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [handleIntersect, threshold]);

  return { sentinelRef, isLoading };
}
